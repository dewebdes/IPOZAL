<?php
    
    /**
    * Theme Compatibility   :   DIVI
    * Introduced at version :   3.17.6* 
    */
    
    if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
    
    
    class WPH_conflict_theme_divi
        {
                        
            static function init()
                {
                    add_action('et_divi_theme_customizer_css_output',           array('WPH_conflict_theme_divi', 'process'));
                    add_action('et_divi_fonts_css_output',                      array('WPH_conflict_theme_divi', 'process'));
                    add_action('et_divi_sidebar_width_css_output',              array('WPH_conflict_theme_divi', 'process'));
                    add_action('et_divi_module_customizer_css_output',          array('WPH_conflict_theme_divi', 'process'));
                    
                    add_action('et_builder_custom_fonts',                       array('WPH_conflict_theme_divi', 'process_et_builder_custom_fonts'));
                }                        
            
              
            static public function process( $buffer )
                {   
                    
                    global $wph;
                    
                    $replacement_list   =   $wph->functions->get_replacement_list();
                                            
                    //replace the urls
                    $buffer =   $wph->functions->content_urls_replacement( $buffer,  $replacement_list ); 
                      
                    return $buffer; 
                               
                }
            
            
            /**
            * Process the cutom fonts
            *     
            * @param mixed $all_custom_fonts
            */
            static public function process_et_builder_custom_fonts( $all_custom_fonts )
                {
                    
                    if  ( ! is_array($all_custom_fonts)     ||  count ( $all_custom_fonts ) < 1 )
                        return $all_custom_fonts;
                    
                    global $wph;
                    
                    $replacement_list   =   $wph->functions->get_replacement_list();
                        
                    foreach  ( $all_custom_fonts as $font   =>  $font_data )
                        {
                            $font_urls  =   $font_data['font_url'];
                            if ( !is_array( $font_urls ) || count ( $font_urls ) < 1 )
                                continue;
                                
                            foreach ( $font_urls    as  $type   =>  $url )
                                {
                                    $font_urls[$type]  =   $wph->functions->content_urls_replacement( $url,  $replacement_list );   
                                }
                            
                            $all_custom_fonts[$font]['font_url']    =   $font_urls;
                        }
                    
                    return $all_custom_fonts;
                       
                }
                                
        }
        
        
    WPH_conflict_theme_divi::init();
    

?>