<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package the-multiple
 */
global $post;
$post_id = "";
if(is_front_page()){
	$post_id = get_option('page_on_front');
}else{
	if($post)
	$post_id = $post->ID;
}
$post_class = get_post_meta( $post_id, 'cartbox_sidebar_layout', true );
if($post_class == ''){$post_class = 'sidebar-right';}

if(is_search() || is_archive() || is_home()){
	$post_class = "sidebar-right";
}
if($post_class=='sidebar-right' || $post_class=='sidebar-both'){
    ?>
    <div id="secondary-right" class="widget-area sidebar-right <?php echo esc_attr($post_class); ?> sidebar">
        <?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
			<?php dynamic_sidebar( 'sidebar-1' ); ?>
		<?php endif; ?>
    </div>
    <?php    
}    
?>