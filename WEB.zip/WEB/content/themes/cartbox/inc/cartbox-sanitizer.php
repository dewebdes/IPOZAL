<?php
/**
* Custom Sanitizer Function 
*/

function cartbox_sanitize_yes_no($input){
        $option = array(
                'yes'   =>  esc_html__('Yes','cartbox'),
                'no'    =>  esc_html__('No','cartbox')
            );
        if(array_key_exists($input, $option)){
            return $input;
        }
        else
            return '';
    }

function cartbox_sanitize_category($input){
    $cartbox_category_lists = cartbox_category_lists();
    if(array_key_exists($input,$cartbox_category_lists)){
        return $input;
    }else{
        return '';
    }
}
