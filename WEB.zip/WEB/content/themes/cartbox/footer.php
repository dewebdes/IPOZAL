<?php
/**
 * @package cartbox
 */

?>

	</div><!-- #content -->

    <footer id="colophon" class="site-footer">
        
         <?php if(is_active_sidebar('cartbox-footer-one') || 
         is_active_sidebar('cartbox-footer-two') || 
         is_active_sidebar('cartbox-footer-three') || 
         is_active_sidebar('cartbox-footer-four')){ ?>
            <div class="site-footer-info">
            
                <div class="tr-container">
                    
                    <?php if(is_active_sidebar('cartbox-footer-one')){ ?>
                        <div id="cartbox-footer-one">
                            <?php dynamic_sidebar('cartbox-footer-one'); ?>
                        </div>
                    <?php } ?>
                    
                    <?php if(is_active_sidebar('cartbox-footer-two')){ ?>
                        <div id="cartbox-footer-two">
                            <?php dynamic_sidebar('cartbox-footer-two'); ?>
                        </div>
                    <?php } ?>
                    
                    <?php if(is_active_sidebar('cartbox-footer-three')){ ?>
                        <div id="cartbox-footer-three">
                            <?php dynamic_sidebar('cartbox-footer-three'); ?>
                        </div>
                    <?php } ?>
                    
                    <?php if(is_active_sidebar('cartbox-footer-four')){ ?>
                        <div id="cartbox-footer-four">
                            <?php dynamic_sidebar('cartbox-footer-four'); ?>
                        </div>
                    <?php } ?>
                
                </div>
            
            </div>
        <?php } ?>
    
    <div class="copyright">
    
        <div class="footer_btm_left">
            <div class="footer-copyright">
                <span class="copyright-text"><?php echo wp_kses_post( get_theme_mod( 'cartbox_footer_setting_cpy_text'));?></span>
                <span class="sep"> | </span>
                <?php printf( esc_html__( 'CartBox By %1$s.', 'cartbox' ), '<a href="'.esc_url( 'http://themeruler.com' ).'" rel="designer">'.esc_html__('Themeruler', 'cartbox').'</a>' ); ?>
            </div><!-- .site-info -->
        </div><!-- .site-info -->
        
    </div><!-- .site-info -->
    
    <?php if(is_active_sidebar('cartbox_payment_footer_image')){ ?>
        <div class="payment-image">
            <?php dynamic_sidebar('cartbox_payment_footer_image'); ?>
        </div>
    <?php } ?>
        
        
    <div id="tr-top"><i class="fa fa-arrow-up"></i></div>
    
</footer><!-- #colophon -->

<?php wp_footer(); ?>
</div>
</body>
</html>
