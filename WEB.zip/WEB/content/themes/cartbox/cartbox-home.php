<?php
/**
 * Template Name: Home Page
*/

get_header(); ?>
<?php if(is_active_sidebar('cartbox-below-slider-section') 
|| is_active_sidebar('cartbox-main-content')):?>
    <div class="ws-main-content">
    	 <main id="main" class="site-main" role="main">
            
            <?php if(is_active_sidebar('cartbox-below-slider-section')):?>
    	       <div class="tr-container">
    		       <div class="below-slider-container">
    			        <?php
    			            dynamic_sidebar('cartbox-below-slider-section');
    			        ?>
    		        </div>
    	        </div>
             <?php endif;
            
    	    if(is_active_sidebar('cartbox-main-content')): ?>
                <div class="cartbox-main-content">
                    <?php dynamic_sidebar('cartbox-main-content'); ?>
                </div>
            <?php endif; ?>
            
    	 </main><!-- #main -->
    </div><!-- #primary -->
<?php endif; ?>
<?php get_footer();?>
