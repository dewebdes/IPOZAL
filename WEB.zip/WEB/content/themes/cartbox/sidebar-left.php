<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package cartbox
 */
global $post;
$post_class = get_post_meta( $post->ID, 'cartbox_sidebar_layout', true );
if($post_class == ''){$post_class = 'sidebar-left';}
?>
    <div id="secondary-left" class="widget-area sidebar-left <?php echo esc_attr($post_class); ?> sidebar">
        <?php if ( is_active_sidebar( 'cartbox-sidebar-left' ) ) : ?>
			<?php dynamic_sidebar( 'cartbox-sidebar-left' ); ?>
		<?php endif; ?>
    </div>
