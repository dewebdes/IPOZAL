jQuery(document).ready(function($){

    /** Header Slider **/
    $("#cartbox-slider-wrap").owlCarousel({
        nav:true,
        margin: 50,
        items:1,
        loop: true,
        autoplay:2500,
        dots:false,
        scrollPerPage: true,
        navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ]
    });
    //Resposive Background image
    $( '.main-slider-wraper .image-slider' ).each( function(){
        var img = $( this ).find( 'img' );
        var src = img.attr( 'src' );
        $( this ).css( 'background-image', 'url( '+ src +' )' );
    });
    /** Gallery Icon **/
    $('.widget .gallery-icon a').each(function(){
        var imglink  = $(this).children('img').attr('src');
        var result = imglink.split('-');
        var count = result.length-1;
        var exclude = result[count].split('.');
        var result_1 = imglink.split('-'+result[count]);
        result_1 = result_1[0]+'.'+exclude[1];
        $(this).attr("href", result_1);
    });
    $(".widget .gallery-icon a").fancybox();

    /** Header Slider **/
    $(".cartbox-main-content .widget_media_gallery .gallery").owlCarousel({
        nav:true,
        margin: 0,
        items:7,
        loop: true,
        autoplay:true,
        autoplayHoverPause:false,
        dots:true,
        navText: [ "", "" ]
    });

   //Entrance WOW JS
    var wow = new WOW(
        {
            boxClass: 'wow', // animated element css class (default is wow)
            animateClass: 'animated', // animation css class (default is animated)
            offset: 150, // distance to the element when triggering the animation (default is 0)
            mobile: true, // trigger animations on mobile devices (default is true)
            live: true, // act on asynchronously loaded content (default is true)
            callback: function (box) {
                // the callback is fired every time an animation is started
                // the argument that is passed in is the DOM node being animated
            }
        }
    );
    wow.init();

    /** Product Tab **/
    $('.tab-button .cat-name').click(function(){
        wow_tab = new WOW(
          {
              boxClass:     'wow_tab',       //default
              animateClass: 'animated',  //default
              offset:       0,           //default
              mobile:       true,        //default
              live:         true         //default
            }
        );
        wow_tab.init();
       var idtab = this.id;
       $('.cartbox-product').hide();
       $('.cartbox-product').removeClass('active');
       $('.tab-button .cat-name').removeClass('active');
       $('.tab-button #'+idtab).addClass('active');
       $('.ps-cat-product #tab-pro-'+idtab).show();
       $('.ps-cat-product #tab-pro-'+idtab).addClass('active');


    });

    /** Product Slider **/
    $(".wrap-pro-slider").owlCarousel({
        nav:true,
        margin: 10,
        loop: true,
        items:4,
        dots:false,
        navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
        responsive:{
          0:{
                items:1
            },
            360:{
                items:1
            },
             411:{
                items:1
            },
            435:{
                items:1
            },
            500:{
                items:2
            },
            650:{
                items:3
            },
            1000:{
                items:4
            }
        }
    });
  /* Testimonial Carousel */
    $('.cartbox-testimonial').owlCarousel({
        nav:true,
        animateIn: 'bounceInRight',
        loop: true,
        responsiveClass: true,
        autoplay: true,
        navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
        responsive: {
            0: {
                items: 1,
            },
            768: {
                items: 1,
            },
            992: {
                items: 1,
            },
            1200: {
                items: 1,
            }
        }

    });

    /** Product Category Slide **/
    $(".er-secondary-pro").owlCarousel({
        nav:true,
        margin: 10,
        loop: true,
        items:3,
        dots:false,
        navText: [ '<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>' ],
        responsive:{
            500:{
                items:1
            },
            650:{
                items:2
            },
            1000:{
                items:2
            },
            1024:{
                items:3
            }
        }
    });

    // Scroll Top
    $('#tr-top').css('right',-65);
    $(window).scroll(function(){
        if($(this).scrollTop() > 300){
            $('#tr-top').css('right',10);
        }else{
            $('#tr-top').css('right',-65);
        }
    });
    $("#tr-top").click(function(){
        $('html,body').animate({scrollTop:0},600);
    });
    
});
