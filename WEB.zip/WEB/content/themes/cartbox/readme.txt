=== CartBox ===

Tags: custom-background, custom-logo, custom-menu, featured-images, threaded-comments, right-sidebar, left-sidebar, three-columns, two-columns, translation-ready, theme-options, e-commerce


== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Copyright ==

CartBox WordPress Theme, Copyright 2018 http://themeruler.com
CartBox is distributed under the terms of the GNU GPL


== Changelog ==

= 1.0.0 =
* Initial release

= 1.0.1 =
* Remove Undifined Function Call

= 1.0.2 =
* Remove unused file
* Add license for image

= 1.0.3 =
* Fix sanitize issue
* Change screenshot

= Styles =	
    Font Awesome 4.6.3 by @davegandy - http://fontawesome.io - @fontawesome
    License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
    
= Scripts =

    Underscores
    License: [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
    URL: http://underscores.me/, 
    (C) 2012-2016 Automattic, Inc.

    OWL Carousel
    License: MIT License
    URL: https://github.com/OwlCarousel2/OwlCarousel2 
    
    Fancybox
    License: Dual licensed under the MIT and GPL licenses:
    URL: http://fancybox.net
        
    WOW
    The MIT License (MIT)
    https://github.com/matthieua/WOW
    Copyright (c) 2016 Matthieu Aussaguel

== Images == 

    All images used in the theme designed by Themeruler under GPL License
    
    Image in screenshot from Pexels
    License The CC0 license - https://www.pexels.com/photo-license/
    https://www.pexels.com/photo/classic-design-elegant-fashion-371095/
    https://www.pexels.com/photo/close-up-photo-of-woman-wearing-black-top-and-blue-denim-button-up-jacket-814194/
    https://www.pexels.com/photo/selective-photo-of-woman-in-gray-hooded-jacket-doing-crouch-position-790357/
    https://www.pexels.com/photo/man-wearing-black-full-zip-biker-jacket-826380/