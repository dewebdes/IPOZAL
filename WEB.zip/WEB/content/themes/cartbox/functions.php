<?php
if ( ! function_exists( 'cartbox_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function cartbox_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on cartbox, use a find and replace
		 * to change 'cartbox' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'cartbox', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );
	    add_theme_support( 'woocommerce' );
	   	add_theme_support( 'wc-product-gallery-zoom' );
	   	add_theme_support( 'wc-product-gallery-lightbox' );
	   	add_theme_support( 'wc-product-gallery-slider' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		add_image_size('cartbox-slider-image', 1920, 800, true);
		add_image_size('cartbox-testimonial-image', 200, 200, true);
		add_image_size('cartbox-single-page', 1200, 600, true);
        add_image_size('cartbox-blog-image', 365, 285, true);
        add_image_size('cartbox-product-category-image', 700, 400, true);

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'cartbox-menu-1' => esc_html__( 'Primary', 'cartbox' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'cartbox_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'cartbox_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function cartbox_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'cartbox_content_width', 640 );
}
add_action( 'after_setup_theme', 'cartbox_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function cartbox_widgets_init() {
    
	register_sidebar( array(
		'name'          => esc_html__( 'Right Sidebar', 'cartbox' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'cartbox' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
    
	register_sidebar( array(
		'name'          => esc_html__( 'Left Sidebar', 'cartbox' ),
		'id'            => 'cartbox-sidebar-left',
		'description'   => esc_html__( 'Add widgets here.', 'cartbox' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	
	register_sidebar( array(
		'name'          => esc_html__( 'Menu Cart', 'cartbox' ),
		'id'            => 'cartbox-menu-cart',
		'description'   => esc_html__( 'Add widgets here.', 'cartbox' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
	 register_sidebar( array(
		'name'          => esc_html__( 'Below Slider Section', 'cartbox' ),
		'id'            => 'cartbox-below-slider-section',
		'description'   => esc_html__( 'Add widgets here.', 'cartbox' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
    
	register_sidebar( array(
		'name'          => esc_html__( 'CartBox Main Content', 'cartbox' ),
		'id'            => 'cartbox-main-content',
		'description'   => esc_html__( 'Add widgets here.', 'cartbox' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) ); 
	register_sidebar( array(
        'name' => esc_html__('Footer One','cartbox'),
        'id' => 'cartbox-footer-one',
        'description' => esc_html__('Appears in the buttom of footer area','cartbox'),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => esc_html__('Footer Two','cartbox'),
        'id' => 'cartbox-footer-two',
        'description' => esc_html__('Appears in the buttom of footer area','cartbox'),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => esc_html__('Footer Three','cartbox'),
        'id' => 'cartbox-footer-three',
        'description' => esc_html__('Appears in the buttom of footer area','cartbox'),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    register_sidebar( array(
        'name' => esc_html__('Footer Four','cartbox'),
        'id' => 'cartbox-footer-four',
        'description' => esc_html__('Appears in the buttom of footer area','cartbox'),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );
    
    register_sidebar( array(
        'name' => esc_html__('Footer Payment Image','cartbox'),
        'id' => 'cartbox_payment_footer_image',
        'description' => esc_html__('Appears in the buttom of footer area','cartbox'),
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        'before_title' => '<h3 class="widget-title">',
        'after_title' => '</h3>',
    ) );

    
}
add_action( 'widgets_init', 'cartbox_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function cartbox_scripts() {
	$cartbox_font_query_args = array('family' => 'Arimo:400,400i,700,700i|Poiret One');
	wp_enqueue_style('cartbox-google-fonts', add_query_arg($cartbox_font_query_args, "//fonts.googleapis.com/css"));
    wp_enqueue_style('owl-carousel',get_template_directory_uri().'/js/owl-carousel/owl.carousel.css');
    wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome/css/font-awesome.min.css', array(), '4.6.3' );
    wp_enqueue_style('jquery-fancybox', get_template_directory_uri() . '/js/fancybox/jquery.fancybox.css' );
	wp_enqueue_style('animation',get_template_directory_uri(). '/js/wow-animation/animate.css');
    wp_enqueue_style('cartbox-woocommerce-style',get_template_directory_uri(). '/woocommerce/woocommerce-style.css');
    wp_enqueue_style('cartbox-style', get_stylesheet_uri() );
	
    wp_enqueue_script('cartbox-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );
    wp_enqueue_script('jquery-fancybox', get_template_directory_uri() . '/js/fancybox/jquery.fancybox.js',array('jquery') );
	wp_enqueue_script('owl-carousel',get_template_directory_uri().'/js/owl-carousel/owl.carousel.js',array('jquery'));
 	wp_enqueue_script('wow', get_template_directory_uri() . '/js/wow-animation/wow.min.js', array('jquery'));
	wp_enqueue_script('cartbox-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20151215', true );
	wp_enqueue_script('cartbox-custom',get_template_directory_uri().'/js/custom.js', array('jquery'), '',true);
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'cartbox_scripts' );
/** Admin Script */
function cartbox_admin_enqueue() {
    $currentscreen = get_current_screen();
    if($currentscreen->id == 'widgets'){
        wp_enqueue_media();
        wp_enqueue_script('cartbox-admin-script', get_template_directory_uri().'/inc/js/admin-script.js',array('jquery'));
        wp_localize_script('cartbox-admin-script', 'cartbox_admin_text', array(
            'upload' => esc_html__('Upload Image', 'cartbox'),
            'remove' => esc_html__('Remove', 'cartbox')
        ));
    }
}
add_action( 'admin_enqueue_scripts', 'cartbox_admin_enqueue' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Custom functions file.
 */

require get_template_directory() . '/inc/cartbox-functions.php';

if(cartbox_is_woocommerce_activated()){
    
    /** Woocommerce Function **/
    require get_template_directory() . '/woocommerce/woocommerce-function.php';
    
}

/** Widgets **/
require get_template_directory() . '/inc/widgets/widgets-field.php';


/**
 * Load Custom Customizer file.
 */
require get_template_directory() . '/inc/cartbox-customizer.php';


/** Widget Blog **/
require get_template_directory() . '/inc/widgets/widget-blog.php';

/** Widget Testimonial **/
require get_template_directory() . '/inc/widgets/widget-testimonial.php';

/** Metaboxe **/
require get_template_directory() . '/inc/cartbox-metabox.php';

//remove_action( 'wp_head', 'feed_links_extra', 3 ); // Display the links to the extra feeds such as category feeds

//remove_action( 'wp_head', 'feed_links', 2 );to the general feeds: Post and Comment Feed

//remove_action( 'wp_head', 'rsd_link' ); // Display the link to the Really Simple Discovery service endpoint, EditURI link

//remove_action( 'wp_head', 'wlwmanifest_o the Windows Live Writer manifest file.

	//remove_action( 'wp_head', 'index_rel_link' ); // index link

	//remove_action( 'wp_head', 'parent_post_rel_link', 10, 0 ); // prev link

	//remove_action( 'wp_head', 'start_post_rel_link', 10, 0 ); // start link

	//remove_action( 'wp_head', 'adjacent_posts_rel_link', 10, 0 ); // Displ to the current post.

	remove_action( 'wp_head', 'wp_generator' ); // Display the XHTML generator that is generated on the wp_head hook, WP version
