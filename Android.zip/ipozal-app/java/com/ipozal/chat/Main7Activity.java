package com.ipozal.chat;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class Main7Activity extends AppCompatActivity {

    WebView NWB1;
    public JavaScriptInterface JSInterface;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        // NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(this), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";

        // NWB1.setVisibility(View.GONE);
        NWB1.setHorizontalScrollBarEnabled(false);

        JSInterface = new JavaScriptInterface(this);
        NWB1.addJavascriptInterface(JSInterface, "JSInterface");
        String furl = "file:///android_asset/map2.html";
        NWB1.loadUrl(furl);

        NWB1.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource(WebView view, String url) {

                ////Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
            }

            public void onPageFinished(WebView view, String url) {
                // //Toast.makeText(thisActivity, "is: "+baseScript.length(), Toast.LENGTH_LONG).show();
                super.onPageFinished(view, url);

            }

        });

//                            NWB1.loadUrl("javascript:var msg='" + location.getLatitude() + "#np#" + location.getLongitude() + "';updateMap(msg);");



        LocationManager lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (!lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            finish();
        }

        //Check whether this app has access to the location permission//


        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);

//If the location permission has been granted, then start the TrackerService//

        if (permission == PackageManager.PERMISSION_GRANTED) {
            startTrackerService();
        } else {

//If the app doesn’t currently have access to the user’s location, then request access//

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_REQUEST);
        }


    }

    private static final int PERMISSIONS_REQUEST = 100;
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[]
            grantResults) {

//If the permission has been granted...//

        if (requestCode == PERMISSIONS_REQUEST && grantResults.length == 1
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            //...then start the GPS tracking service//

            startTrackerService();
        } else {

//If the user denies the permission request, then display a toast with some more information//

            Toast.makeText(this, "Please enable location services to allow GPS tracking", Toast.LENGTH_SHORT).show();
        }
    }

//Start the TrackerService//

    private void startTrackerService() {
        //startService(new Intent(this, TrackingService.class));

//Notify the user that tracking has been enabled//

        Toast.makeText(this, "GPS tracking enabled", Toast.LENGTH_SHORT).show();

//Close MainActivity//

        //finish();


        starttt();

    }

    private void starttt(){
        buildNotification();
        loginToFirebase();
        requestLocationUpdates();
    }
    private void buildNotification() {
        String stop = "stop";
        registerReceiver(stopReceiver, new IntentFilter(stop));
        PendingIntent broadcastIntent = PendingIntent.getBroadcast(
                this, 0, new Intent(stop), PendingIntent.FLAG_UPDATE_CURRENT);
        // Create the persistent notification
        Notification.Builder builder = new Notification.Builder(this)
                .setContentTitle(getString(R.string.app_name))
                .setContentText(getString(R.string.tracking_enabled_notif))

//Make this notification ongoing so it can’t be dismissed by the user//

                .setOngoing(true)
                .setContentIntent(broadcastIntent)
                .setSmallIcon(R.drawable.tracking_enabled);
        //startForeground(1, builder.build());
    }

    protected BroadcastReceiver stopReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {

//Unregister the BroadcastReceiver when the notification is tapped//

            unregisterReceiver(stopReceiver);

//Stop the Service//

            //stopSelf();
        }
    };

    private void loginToFirebase() {

//Authenticate with Firebase, using the email and password we created earlier//

        String email = getString(R.string.test_email);
        String password = getString(R.string.test_password);

//Call OnCompleteListener if the user is signed in successfully//


        FirebaseAuth.getInstance().signInWithEmailAndPassword(
                email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(Task<AuthResult> task) {

//If the user has been authenticated...//

                if (task.isSuccessful()) {

//...then call requestLocationUpdates//

                    requestLocationUpdates();
                } else {

//If sign in fails, then log the error//

                    Log.d(TAG, "Firebase authentication failed");
                }
            }
        });
    }
    private static final String TAG = "";
//Initiate the request to track the device's location//

    private void requestLocationUpdates() {
        LocationRequest request = new LocationRequest();

//Specify how often your app should request the device’s location//

        request.setInterval(10000);

//Get the most accurate location data available//

        request.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        FusedLocationProviderClient client = LocationServices.getFusedLocationProviderClient(this);
        final String path = getString(R.string.firebase_path);
        int permission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION);

//If the app currently has access to the location permission...//

        if (permission == PackageManager.PERMISSION_GRANTED) {

//...then request location updates//

            client.requestLocationUpdates(request, new LocationCallback() {
                @Override
                public void onLocationResult(LocationResult locationResult) {

//Get a reference to the database, so your app can perform read and write operations//

                    //DatabaseReference ref = FirebaseDatabase.getInstance().getReference(path);
                    final Location location = locationResult.getLastLocation();
                    NWB1.loadUrl("javascript:var msg='" + location.getLatitude() + "#np#" + location.getLongitude() + "';updateMap(msg);");

                    if (location != null) {

//Save the location data to the database//

                        //NWB1.loadUrl("javascript:var msg='" + location.getLatitude() + "#np#" + location.getLongitude() + "';updateMap(msg);");

                        /*Handler handler = new Handler(Looper.getMainLooper());
                        handler.post(new Runnable() {

                            @Override
                            public void run() {
                                Toast.makeText(MainActivity.this.getApplicationContext(),location.toString(),Toast.LENGTH_SHORT).show();
                            }
                        });
*/

                        //ref.setValue(location);
                    }
                }
            }, null);
        }
    }


    public void manageWBcommands(String msg) {

        // Toast.makeText(this,msg, Toast.LENGTH_LONG).show();


        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        if (cmd.trim().equals("register2")){
            //   register2(msg);
        }

        if (cmd.trim().equals("startavatar2")) {
            //    startavatar2();
        }
        if (cmd.trim().equals("startavatar")) {
            //     startavatar();
        }

        if (cmd.trim().equals("savestat")) {
            //  takeScreenshot();
        }
        if (cmd.trim().equals("startcamera")) {
            //   startcamera();
        }

        if (cmd.trim().equals("doalert")) {

            String prm1 = foo[1];

            //  Toast.makeText(this,prm1, Toast.LENGTH_LONG).show();

        }

        if (cmd.trim().equals("savelogin")){
        }

        if (cmd.trim().equals("signInGoogle")){
            //signInGoogle();
        }
        if (cmd.trim().equals("signInFB")){
            // signInFB();
        }
        //signInGoogleBase
        if (cmd.trim().equals("signInGoogleBase")){
            //  signInGoogleBase();
        }
//openMap
        if (cmd.trim().equals("openMap")){
            //  openMap();
        }

    }

    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
            // manageWBcommands(message);

        }
    }
    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }

    private class JavaScriptInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void changeActivity(String m)
        {
            manageWBcommands(m);
            //Intent i = new Intent(JavascriptInterfaceActivity.this, nextActivity.class);
            //startActivity(i);
            //finish();
        }

    }
}
