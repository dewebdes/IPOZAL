package com.ipozal.chat;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.HashMap;

public class DatabaseHandler extends SQLiteOpenHelper {

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 2;
//    private static final String KEY_ID = "uid";

    // Database Name
    private static final String DATABASE_NAME = "nader";

    // Login table name
    private static final String TABLE_LOGIN = "login";

    // Login Table Columns names
    private static final String KEY_ID = "uid";//"id";
//    private static final int DATABASE_VERSION = 2;

    private static final String KEY_NAME = "name";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_UID = "uid";
    private static final String KEY_CREATED_AT = "created_at";
    public static final String dieplat="dieplat";//foo[0];
    public static final String dietkn="dietkn";//foo[1];
    public static final String dieavatarsrc="dieavatarsrc";//foo[2];
    public static final String dieregfullname="dieregfullname";//foo[3];
    public static final String dieregmail="dieregmail";//foo[4];
    public static final String ddieregpas="ddieregpas";//foo[5];
    public static final String ddieregrepas="ddieregrepas";//foo[6];
    public static final String diesendnotify="diesendnotify";//foo[7];
    public static final String diesendmailnot="diesendmailnot";//foo[8];

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {

    }

    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOGIN);

        // Create tables again
        onCreate(db);
    }

    /**
     * Storing user details in database
     * */
    public void addUser(String msg){//}, String email, String uid, String created_at) {
        String[] foo = msg.split("#np#");
        //"register2#np#"+
        String dieplat=foo[0];
        String dietkn=foo[1];
        String dieavatarsrc=foo[2];
        String dieregfullname=foo[3];
        String dieregmail=foo[4];
        String ddieregpas=foo[5];
        String ddieregrepas=foo[6];
        String diesendnotify=foo[7];
        String diesendmailnot=foo[8];

        SQLiteDatabase db = this.getWritableDatabase();

        String CREATE_LOGIN_TABLE = "CREATE TABLE " + TABLE_LOGIN + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + KEY_NAME + " TEXT,"
                + KEY_EMAIL + " TEXT UNIQUE,"
                //+ KEY_UID + " INTEGER,"
                + KEY_CREATED_AT + " TEXT,"
                + dieplat + " TEXT,"
                + dietkn + " TEXT,"
                + dieavatarsrc + " TEXT,"
                + dieregfullname + " TEXT,"
                + dieregmail + " TEXT,"
                + ddieregpas + " TEXT,"
                + ddieregrepas + " TEXT,"
                + diesendnotify + " TEXT,"
                + diesendmailnot + " TEXT" + ")";
      //  db.execSQL(CREATE_LOGIN_TABLE);

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, dieplat); // Name
        values.put(KEY_EMAIL, dietkn); // Email
      //  values.put(KEY_UID, dieavatarsrc); // Email
        values.put(KEY_CREATED_AT, dieregfullname); // Created At
        values.put(dieplat, foo[0]);
        values.put(dietkn, foo[1]);
        values.put(dieavatarsrc, foo[2]);
        values.put(dieregfullname, foo[3]);
        values.put(dieregmail, foo[4]);
        values.put(ddieregpas, foo[5]);
        values.put(ddieregrepas, foo[6]);
        values.put(diesendnotify, foo[7]);
        values.put(diesendmailnot, foo[8]);


        // Inserting Row
        db.insert(TABLE_LOGIN, null, values);
        db.close(); // Closing database connection
    }

    /**
     * Getting user data from database
     * */
    public HashMap<String, String> getUserDetails(){
        HashMap<String,String> user = new HashMap<String,String>();
        String selectQuery = "SELECT  * FROM " + TABLE_LOGIN;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        // Move to first row
        cursor.moveToFirst();
        if(cursor.getCount() > 0){
            user.put("name", cursor.getString(1));
            user.put("email", cursor.getString(2));
            //user.put("uid", cursor.getString(3));
            user.put("created_at", cursor.getString(4));

            user.put("dieplat", cursor.getString(5));
            user.put("dietkn", cursor.getString(6));
            user.put("dieavatarsrc", cursor.getString(7));
            user.put("dieregfullname", cursor.getString(8));
            user.put("dieregmail", cursor.getString(9));
            user.put("ddieregpas", cursor.getString(10));
            user.put("ddieregrepas", cursor.getString(11));
            user.put("diesendnotify", cursor.getString(12));
            user.put("diesendmailnot", cursor.getString(13));
            //user.put("created_at", cursor.getString(4));

        }
        cursor.close();
        db.close();
        // return user
        return user;
    }

    /**
     * Getting user login status
     * return true if rows are there in table
     * */
    public int getRowCount() {
        String countQuery = "SELECT  * FROM " + TABLE_LOGIN;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        int rowCount = cursor.getCount();
        db.close();
        cursor.close();

        // return row count
        return rowCount;
    }

    /**
     * Re crate database
     * Delete all tables and create them again
     * */
    public void resetTables(){
        SQLiteDatabase db = this.getWritableDatabase();
        // Delete All Rows
        db.delete(TABLE_LOGIN, null, null);
        db.close();
    }

}
