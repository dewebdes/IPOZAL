package com.ipozal.chat;

public class Identifiers {
    static String android_id; //AdvertisingId
    static String restUrl = "http://192.168.0.103/android/"; //localhost
}