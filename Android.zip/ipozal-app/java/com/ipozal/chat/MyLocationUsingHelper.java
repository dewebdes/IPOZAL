package com.ipozal.chat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.ipozal.chat.LocationUtil.LocationHelper;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient.ConnectionCallbacks;
import com.google.android.gms.common.api.GoogleApiClient.OnConnectionFailedListener;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MyLocationUsingHelper extends AppCompatActivity implements ConnectionCallbacks,
        OnConnectionFailedListener, OnRequestPermissionsResultCallback {


    @BindView(R.id.btnLocation)
    Button btnProceed;
    @BindView(R.id.tvAddress)
    TextView tvAddress;
    @BindView(R.id.tvEmpty)
    TextView tvEmpty;
    @BindView(R.id.rlPickLocation)
    RelativeLayout rlPick;

    private Location mLastLocation;

    double latitude;
    double longitude;

    LocationHelper locationHelper;

    WebView NWB1;
    public JavaScriptInterface JSInterface;
    //public Main5Activity.JavaScriptInterface JSInterface;

    private FusedLocationProviderClient fusedLocationClient;

    private static final int PERMISSIONS_REQUEST = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location_service);

        locationHelper = new LocationHelper(this);
        locationHelper.checkpermission();

        ButterKnife.bind(this);

        rlPick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mLastLocation = locationHelper.getLocation();

                if (mLastLocation != null) {
                    latitude = mLastLocation.getLatitude();
                    longitude = mLastLocation.getLongitude();
                    getAddress();

                } else {

                    if (btnProceed.isEnabled())
                        btnProceed.setEnabled(false);

                    showToast("Couldn't get the location. Make sure location is enabled on the device");
                }
            }
        });


        btnProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showToast("Proceed to the next step");
            }
        });

        // check availability of play services
        if (locationHelper.checkPlayServices()) {

            // Building the GoogleApi client
            locationHelper.buildGoogleApiClient();
        }


        //------------------- nwb

        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        // NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(this), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";

        // NWB1.setVisibility(View.GONE);
        NWB1.setHorizontalScrollBarEnabled(false);

        JSInterface = new MyLocationUsingHelper.JavaScriptInterface(this);
        NWB1.addJavascriptInterface(JSInterface, "JSInterface");
        String furl = "file:///android_asset/home.html";
        NWB1.loadUrl(furl);

        NWB1.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource(WebView view, String url) {

                ////Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
            }

            public void onPageFinished(WebView view, String url) {
                // //Toast.makeText(thisActivity, "is: "+baseScript.length(), Toast.LENGTH_LONG).show();
                super.onPageFinished(view, url);

            }

        });


        final Handler h = new Handler();
        h.postDelayed(new Runnable() {
            private long time = 0;

            @Override
            public void run() {
                getAddress3();
                // do stuff then
                // can call h again after work!
                //time += 10000;
                //Log.d("TimerExample", "Going for... " + time);
                h.postDelayed(this, 10000);
            }
        }, 3000);

       /* MyLocation.LocationResult locationResult = new MyLocation.LocationResult(){
            @Override
            public void gotLocation(Location location){
                //Got the location!
                latitude = location.getLatitude();
                longitude = location.getLongitude();

                // locationAddress = locationHelper.getAddress(latitude, longitude);


            }
        };*/
        //  MyLocation myLocation = new MyLocation();
        //myLocation.getLocation(this, locationResult);

        // getAddress3();


        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

    }


    public void getAddress3() {
        /*SingleShotLocationProvider.requestSingleUpdate(context,
                new SingleShotLocationProvider.LocationCallback() {
                    @Override public void onNewLocationAvailable(GPSCoordinates location) {
                        Log.d("Location", "my location is " + location.toString());
                    }
                });*/

        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, new OnSuccessListener<Location>() {
                    @Override
                    public void onSuccess(Location location) {
                        // Got last known location. In some rare situations this can be null.
                        if (location != null) {
                            // Logic to handle location object
                            NWB1.loadUrl("javascript:var msg='" + location.getLatitude() + "#np#" + location.getLongitude() + "';updateMap(msg);");
                        }
                    }
                });


    }
    public void getAddress2()
    {


//        mLastLocation=locationHelper.getLocation();
  //      latitude = mLastLocation.getLatitude();
    //    longitude = mLastLocation.getLongitude();




        mLastLocation=locationHelper.getLocation();

        if (mLastLocation != null) {
            Address locationAddress;

            latitude = mLastLocation.getLatitude();
            longitude = mLastLocation.getLongitude();

           // locationAddress = locationHelper.getAddress(latitude, longitude);

            NWB1.loadUrl("javascript:var msg='" + latitude + "#np#" + longitude + "';updateMap(msg);");
            locationHelper=new LocationHelper(this);
            locationHelper.checkpermission();
            locationHelper.buildGoogleApiClient();
        }

    }
    public void getAddress()
    {
        Address locationAddress;

        locationAddress=locationHelper.getAddress(latitude,longitude);

       // NWB1.loadUrl("javascript:var msg='" + latitude + "#np#" + longitude + "';updateMap(msg);");

        if(locationAddress!=null)
        {

            String address = locationAddress.getAddressLine(0);
            String address1 = locationAddress.getAddressLine(1);
            String city = locationAddress.getLocality();
            String state = locationAddress.getAdminArea();
            String country = locationAddress.getCountryName();
            String postalCode = locationAddress.getPostalCode();


            String currentLocation;

            if(!TextUtils.isEmpty(address))
            {
                currentLocation=address;

                if (!TextUtils.isEmpty(address1))
                    currentLocation+="\n"+address1;

                if (!TextUtils.isEmpty(city))
                {
                    currentLocation+="\n"+city;

                    if (!TextUtils.isEmpty(postalCode))
                        currentLocation+=" - "+postalCode;
                }
                else
                {
                    if (!TextUtils.isEmpty(postalCode))
                        currentLocation+="\n"+postalCode;
                }

                if (!TextUtils.isEmpty(state))
                    currentLocation+="\n"+state;

                if (!TextUtils.isEmpty(country))
                    currentLocation+="\n"+country;

                tvEmpty.setVisibility(View.GONE);
                tvAddress.setText(currentLocation);
                tvAddress.setVisibility(View.VISIBLE);

                if(!btnProceed.isEnabled())
                    btnProceed.setEnabled(true);
            }

        }
        else
            showToast("Something went wrong - > " + latitude + " - " + longitude);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        locationHelper.onActivityResult(requestCode,resultCode,data);
    }


    @Override
    protected void onResume() {
        super.onResume();
        locationHelper.checkPlayServices();
    }

    /**
     * Google api callback methods
     */
    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.i("Connection failed:", " ConnectionResult.getErrorCode() = "
                + result.getErrorCode());
    }

    @Override
    public void onConnected(Bundle arg0) {

        // Once connected with google api, get the location
        mLastLocation=locationHelper.getLocation();
    }

    @Override
    public void onConnectionSuspended(int arg0) {
        locationHelper.connectApiClient();
    }


    // Permission check functions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        // redirects to utils
        locationHelper.onRequestPermissionsResult(requestCode,permissions,grantResults);

    }

    public void showToast(String message)
    {
        Toast.makeText(this,message,Toast.LENGTH_SHORT).show();
    }

    public void manageWBcommands(String msg) {

        // Toast.makeText(this,msg, Toast.LENGTH_LONG).show();


        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        if (cmd.trim().equals("register2")){
            //   register2(msg);
        }

        if (cmd.trim().equals("startavatar2")) {
            //    startavatar2();
        }
        if (cmd.trim().equals("startavatar")) {
            //     startavatar();
        }

        if (cmd.trim().equals("savestat")) {
            //  takeScreenshot();
        }
        if (cmd.trim().equals("startcamera")) {
            //   startcamera();
        }

        if (cmd.trim().equals("doalert")) {

            String prm1 = foo[1];

            //  Toast.makeText(this,prm1, Toast.LENGTH_LONG).show();

        }

        if (cmd.trim().equals("savelogin")){
        }

        if (cmd.trim().equals("signInGoogle")){
            //signInGoogle();
        }
        if (cmd.trim().equals("signInFB")){
           // signInFB();
        }
        //signInGoogleBase
        if (cmd.trim().equals("signInGoogleBase")){
          //  signInGoogleBase();
        }
//openMap
        if (cmd.trim().equals("openMap")){
          //  openMap();
        }

    }

    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
            // manageWBcommands(message);

        }
    }
    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }

    private class JavaScriptInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void changeActivity(String m)
        {
            manageWBcommands(m);
            //Intent i = new Intent(JavascriptInterfaceActivity.this, nextActivity.class);
            //startActivity(i);
            //finish();
        }

    }


}
