package com.ipozal.chat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class Main5Activity extends AppCompatActivity {
    WebView NWB1;
    public JavaScriptInterface JSInterface;
    private ShimmerFrameLayout mShimmerViewContainer;
    private GoogleSignInClient mGoogleSignInClient;
    private int RC_SIGN_IN = 100;

    private FirebaseAuth mAuth;
    public CallbackManager callbackManager;
    public LoginButton loginButton;

    public Context dsi;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FacebookSdk.setApplicationId("348043555852741");
        FacebookSdk.setClientToken("ddfb764569f0ac305f76c9d35e20010e");//.setApplicationId("348043555852741");
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_main5);

        dsi = this;

        mShimmerViewContainer = findViewById(R.id.shimmer_view_container);
        mShimmerViewContainer.startShimmerAnimation();

        NWB1 = (WebView) findViewById(R.id.NWB1);
        NWB1.getSettings().setJavaScriptEnabled(true);
        // NWB1.addJavascriptInterface(new WebViewJavaScriptInterface(this), "app");
        NWB1.getSettings().setRenderPriority(WebSettings.RenderPriority.HIGH);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            NWB1.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        } else {
            NWB1.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        }
        //NWB1.setWebViewClient(new MyBrowser());
        NWB1.getSettings().setLoadsImagesAutomatically(true);
        NWB1.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        NWB1.getSettings().setAppCacheEnabled(false);
        NWB1.getSettings().setCacheMode(WebSettings.LOAD_NO_CACHE);
        //NWB1.getSettings().setJavaScriptEnabled(true);
        NWB1.getSettings().setDomStorageEnabled(true);
        NWB1.getSettings().setUseWideViewPort(true);
        NWB1.setWebChromeClient(new WebChromeClient());
        NWB1.setScrollbarFadingEnabled(true);
        NWB1.clearCache(true);
        NWB1.setVerticalScrollBarEnabled(false);
        NWB1.getSettings().setAllowUniversalAccessFromFileURLs(true);
        //String furl = "http://transport.maxim.shop/KookiKlub/appFa";

        NWB1.setVisibility(View.GONE);
        NWB1.setHorizontalScrollBarEnabled(false);

        JSInterface = new JavaScriptInterface(this);
        NWB1.addJavascriptInterface(JSInterface, "JSInterface");
        String furl = "file:///android_asset/home.html";
        NWB1.loadUrl(furl);

        NWB1.setWebViewClient(new WebViewClient() {
            @Override
            public void onLoadResource(WebView view, String url) {

                ////Toast.makeText(getContext(), "+++ on load res call", Toast.LENGTH_LONG).show();
            }

            public void onPageFinished(WebView view, String url) {
                // //Toast.makeText(thisActivity, "is: "+baseScript.length(), Toast.LENGTH_LONG).show();
                super.onPageFinished(view, url);

            }

        });

        final Handler handler = new Handler();
        final Context conx = this;
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                //Toast.
                //Toast.makeText(conx, "The new Row Id is ", Toast.LENGTH_LONG).show();
                NWB1.setVisibility(View.VISIBLE);
                GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                        .requestEmail()
                        .build();
                mGoogleSignInClient = GoogleSignIn.getClient(dsi, gso);

                GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(dsi);
                updateUI(account);
                // account.getEmail()

            }
        }, 7000);


        mAuth = FirebaseAuth.getInstance();


//---------------------------------------------------------
        /*CallbackManager callbackManager = CallbackManager . Factory . create ();




        LoginButton loginButton = (LoginButton) findViewById(R.id.login_button);
        loginButton.setReadPermissions("email");
        // If using in a fragment
        //loginButton.setFragment(this);

        // Callback registration
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // App code
            }

            @Override
            public void onCancel() {
                // App code
            }

            @Override
            public void onError(FacebookException exception) {
                // App code
            }
        });*/

        //--------------------------------------------------------

        callbackManager = CallbackManager.Factory.create();
        loginButton = (LoginButton) findViewById(R.id.connectWithFbButton);
        List<String> permissionNeeds = Arrays.asList("user_photos", "email", "user_birthday", "public_profile");
        loginButton.setReadPermissions(permissionNeeds);

        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                // Toast.makeText(conx, "The new Row Id is ", Toast.LENGTH_LONG).show();

                System.out.println("onSuccess");
                GraphRequest request = GraphRequest.newMeRequest
                        (loginResult.getAccessToken(), new GraphRequest.GraphJSONObjectCallback() {
                            @Override
                            public void onCompleted(JSONObject object, GraphResponse response) {
                                // Application code
                                Log.v("LoginActivity", response.toString());
                                //System.out.println("Check: " + response.toString());
                                try {
                                    String id = object.getString("id");
                                    String name = object.getString("name");
                                    String email = object.getString("email");
                                    // String gender = object.getString("gender");
                                    String birthday = object.getString("birthday");
                                    String avatar = "https://graph.facebook.com/" + id + "/picture?type=large";

                                    //NWB1.loadUrl("javascript:var msg='"+email+"#np#"+name+"';updateusinfo(msg);");
                                    NWB1.loadUrl("javascript:var msg='" + email + "#np#" + name + "#np#" + avatar + "';updateusinfo(msg);");


                                    //System.out.println(id + ", " + name + ", " + email + ", " + ", " + birthday);
                                } catch (JSONException e) {
                                    e.printStackTrace();
                                }

                            }
                        });
                Bundle parameters = new Bundle();
                parameters.putString("fields", "id,name,email,gender, birthday");
                request.setParameters(parameters);
                request.executeAsync();
            }

            @Override
            public void onCancel() {
                System.out.println("onCancel");
            }

            @Override
            public void onError(FacebookException exception) {
                System.out.println("onError");
                Toast.makeText(conx, "The new Row Id is ", Toast.LENGTH_LONG).show();

                Log.v("LoginActivity", exception.getCause().toString());
            }
        });

    }

    @Override
    public void onStart() {
        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        //FirebaseUser currentUser = mAuth.getCurrentUser();
        // updateUI(currentUser);

    }

    public String saveduse = "";

    private void signInGoogleBase() {


        if (!saveduse.equals("")) {
            signInGoogle();
        }


        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user != null) {
            // Name, email address, and profile photo Url
            String name = user.getDisplayName();
            String email = user.getEmail();
            Uri photoUrl = user.getPhotoUrl();

            // Check if user's email is verified
            boolean emailVerified = user.isEmailVerified();

            // The user's ID, unique to the Firebase project. Do NOT use this value to
            // authenticate with your backend server, if you have one. Use
            // FirebaseUser.getIdToken() instead.
            String uid = user.getUid();

            NWB1.loadUrl("javascript:var msg='" + email + "#np#" + name + "';updateusinfo(msg);");

        }
    }

    /*public static Author getAuthor() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        if (user == null) return null;
        return new Author(user.getDisplayName(), user.getPhotoUrl() != null ? user.getPhotoUrl().toString() : null, user.getUid());
    }*/
    private void updateUI(GoogleSignInAccount acc) {
        try {
            Uri personPhoto = acc.getPhotoUrl();
            Log.v("LoginActivity", "******************************************************\n\r\n\r********************************\n\r");
            //Log.v("LoginActivity", (personPhoto.equals(null)).toString());
            Log.v("LoginActivity", "******************************************************\n\r\n\r********************************\n\r");
            NWB1.loadUrl("javascript:var msg='" + acc.getEmail() + "#np#" + acc.getDisplayName() + "#np#" + personPhoto.toString() + "';updateusinfo(msg);");
        } catch (NullPointerException e) {
            FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
            //if (user == null) return null;
            String img = "";
            try {
                img = user.getPhotoUrl().toString();
            } catch (NullPointerException e2) {
                img = "https://www.google.com/images/branding/googlelogo/2x/googlelogo_color_92x30dp.png";
            }
            try {
                NWB1.loadUrl("javascript:var msg='" + acc.getEmail() + "#np#" + acc.getDisplayName() + "#np#" + img + "';updateusinfo(msg);");
            } catch (NullPointerException e3) {
            }
            //System.out.print("NullPointerException Caught");
        }
    }

    private void signInGoogle() {

        Intent signInIntent = mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);

    }

    public void go2home() {

    }

    private Location getLastKnownLocation() {
        LocationManager mLocationManager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        List<String> providers = mLocationManager.getProviders(true);
        Location bestLocation = null;
        for (String provider : providers) {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return null;
            }
            Location l = mLocationManager.getLastKnownLocation(provider);
            //ALog.d("last known location, provider: %s, location: %s", provider,
              //      l);

            if (l == null) {
                continue;
            }
            if (bestLocation == null
                    || l.getAccuracy() < bestLocation.getAccuracy()) {
               // ALog.d("found best last known location: %s", l);
                bestLocation = l;
            }
        }
        if (bestLocation == null) {
            return null;
        }
        return bestLocation;
    }
    public void openMap() {
        //onLocationChanged0(getLastKnownLocation());
        Intent intent = new Intent(this, Main7Activity.class);
        //Intent intent = new Intent(this, MapRealAct.class);
      //  EditText editText = (EditText) findViewById(R.id.editText);
        //String message = editText.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    //@Override
    public void onLocationChanged0(Location loc) {
        //editLocation.setText("");
        //pb.setVisibility(View.INVISIBLE);
        /*Toast.makeText(
                getBaseContext(),
                "Location changed: Lat: " + loc.getLatitude() + " Lng: "
                        + loc.getLongitude(), Toast.LENGTH_SHORT).show();*/
        String longitude = "Longitude: " + loc.getLongitude();
        //Log.v(TAG, longitude);
        String latitude = "Latitude: " + loc.getLatitude();
        //Log.v(TAG, latitude);

        /*------- To get city name from coordinates -------- */
        String cityName = null;
        Geocoder gcd = new Geocoder(getBaseContext(), Locale.getDefault());
        List<Address> addresses;
        try {
            addresses = gcd.getFromLocation(loc.getLatitude(),
                    loc.getLongitude(), 1);
            if (addresses.size() > 0) {
                System.out.println(addresses.get(0).getLocality());
                cityName = addresses.get(0).getLocality();
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        String s = longitude + "\n" + latitude + "\n\nMy Current City is: "
                + cityName;
        //editLocation.setText(s);

        NWB1.loadUrl("javascript:var msg='" + s + "';updatemapinfo(msg);");

    }
/*
    @Override
    public void onProviderDisabled(String provider) {}

    @Override
    public void onProviderEnabled(String provider) {}

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}
  */
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        //Log.d(TAG, "onActivityResult:" + requestCode + ":" + resultCode + ":" + data);

        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
            go2home();
        }else{
            //If not request code is RC_SIGN_IN it must be facebook
            callbackManager.onActivityResult(requestCode, resultCode, data);
        }
    }
    //@Override
    public void onActivityResult0(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Result returned from launching the Intent from GoogleSignInClient.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }else{
            Toast.makeText(dsi, "The new Row Id is ", Toast.LENGTH_LONG).show();
            AccessToken token = AccessToken.getCurrentAccessToken();
            //if (token != null) {
              //  Toast.makeText(getActivity(), token, Toast.LENGTH_LONG).show();
            //}
            //PackageInstaller.Session session = PackageInstaller.Session.getActiveSession();
            //if (requestCode == Constants.FACEBOOK_AUTH_RESULT_CODE) {
            //FacebookSdk.authorizeCallback(requestCode, resultCode, data);
            //} else {
              //  Log.e(TAG, "onActivityResult Error : Authentication Error");
            //}
            Log.v("LoginActivity", token.toString());
            GraphRequest request = GraphRequest.newMeRequest
                    (token, new GraphRequest.GraphJSONObjectCallback()
                    {
                        @Override
                        public void onCompleted(JSONObject object, GraphResponse response)
                        {
                            // Application code
                            Log.v("LoginActivity", response.toString());
                            //System.out.println("Check: " + response.toString());
                            try
                            {
                                String id = object.getString("id");
                                String name = object.getString("name");
                                String email = object.getString("email");
                                String gender = object.getString("gender");
                                String birthday = object.getString("birthday");

                                NWB1.loadUrl("javascript:var msg='"+email+"#np#"+name+"';updateusinfo(msg);");


                                System.out.println(id + ", " + name + ", " + email + ", " + gender + ", " + birthday);
                            }
                            catch (JSONException e)
                            {
                                e.printStackTrace();
                            }

                        }
                    });
            Bundle parameters = new Bundle();
            parameters.putString("fields", "id,name,email,gender, birthday");
            request.setParameters(parameters);
            request.executeAsync();

        }
    }
    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);


            SharedPreferences prefs = getSharedPreferences("shared_pref_name", MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("email", account.getEmail());
            editor.putString("name", account.getDisplayName());
            editor.putBoolean("hasLogin",true);
            editor.apply();

            //image with glide
            //Glide.with(this).load(acc.getPhotoUrl()).into(photo);

            // Signed in successfully, show authenticated UI.
            updateUI(account);
        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            //Log.w(TAG, "signInResult:failed code=" + e.getStatusCode());
            updateUI(null);
        }
    }
    private void signInFB(){

        //loginButton.performClick();
        LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "user_friends"));


    }
    public void manageWBcommands(String msg) {

       // Toast.makeText(this,msg, Toast.LENGTH_LONG).show();


        String[] foo = msg.split("#np#");
        String cmd = foo[0];
        String param = "";
        try {
            param = foo[1];
        } catch (Exception ex) {
            param = "";
        }

        if (cmd.trim().equals("register2")){
         //   register2(msg);
        }

        if (cmd.trim().equals("startavatar2")) {
        //    startavatar2();
        }
        if (cmd.trim().equals("startavatar")) {
       //     startavatar();
        }

        if (cmd.trim().equals("savestat")) {
            //  takeScreenshot();
        }
        if (cmd.trim().equals("startcamera")) {
         //   startcamera();
        }

        if (cmd.trim().equals("doalert")) {

            String prm1 = foo[1];

          //  Toast.makeText(this,prm1, Toast.LENGTH_LONG).show();

        }

        if (cmd.trim().equals("savelogin")){
        }

        if (cmd.trim().equals("signInGoogle")){
            signInGoogle();
        }
        if (cmd.trim().equals("signInFB")){
            signInFB();
        }
        //signInGoogleBase
        if (cmd.trim().equals("signInGoogleBase")){
            signInGoogleBase();
        }
//openMap
        if (cmd.trim().equals("openMap")){
            openMap();
        }

    }

    public class WebViewJavaScriptInterface {

        private Context context;

        /*
         * Need a reference to the context in order to sent a post message
         */
        public WebViewJavaScriptInterface(Context context) {
            this.context = context;
        }

        /*
         * This method can be called from Android. @JavascriptInterface
         * required after SDK version 17.
         */
        @JavascriptInterface
        public void makeToast(String message, boolean lengthLong) {

            //((PagerActivity)getActivity()).manageWBcommands(message);
            // manageWBcommands(message);

        }
    }
    private class MyBrowser extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            view.loadUrl(url);
            return true;
        }


        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            view.clearCache(true);

            //hideWait();

            /*
            //Toast.makeText(context, message, Toast.LENGTH_LONG).show();
            //wv1.loadUrl("javascript:var msg=window.location.href;app.makeToast(msg, '123');");
            NWB1.loadUrl("javascript:var msg='urlLoaded#np#'+window.location.href;app.makeToast(msg, '123');");

            //--------------------- hack1 ---------------
            String jqCmd = "jQuery('input[type=text]').click(function(){app.makeToast('hideWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doCancel').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = jqCmd + "jQuery('#doPay').click(function(){app.makeToast('showWait', '123');});";
            jqCmd = "if(jQuery('#doPay').length>0){" + jqCmd + "};";
            NWB1.loadUrl("javascript:" + jqCmd);
            //--------------------------------------------
*/

        }
    }

    private class JavaScriptInterface {
        Context mContext;

        /** Instantiate the interface and set the context */
        JavaScriptInterface(Context c) {
            mContext = c;
        }

        @JavascriptInterface
        public void changeActivity(String m)
        {
            manageWBcommands(m);
            //Intent i = new Intent(JavascriptInterfaceActivity.this, nextActivity.class);
            //startActivity(i);
            //finish();
        }

    }


}

