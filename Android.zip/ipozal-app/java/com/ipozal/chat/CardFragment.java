package com.ipozal.chat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.CardView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;


public class CardFragment extends Fragment {

    private CardView cardView;

    public static Fragment getInstance(int position) {
        CardFragment f = new CardFragment();
        Bundle args = new Bundle();
        args.putInt("position", position);
        f.setArguments(args);

        return f;
    }

    @SuppressLint("DefaultLocale")
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.item_viewpager, container, false);

        cardView = (CardView) view.findViewById(R.id.cardView);
        cardView.setMaxCardElevation(cardView.getCardElevation() * CardAdapter.MAX_ELEVATION_FACTOR);

       // TextView title = (TextView) view.findViewById(R.id.title);
        Button button = (Button)view.findViewById(R.id.button);

        //title.setText(String.format("Card %d", getArguments().getInt("position")));

/*
* HOTEL
FLIGHT
VISA
TOUR
TRANSFER
BUS
* */

        ImageView icon = (ImageView) view.findViewById(R.id.iconv);
        int pos = getArguments().getInt("position");
        switch (pos){
            case 0:
                icon.setImageResource(R.drawable.allinone1);
                button.setText("All In One");
                break;
            case 1:
                icon.setImageResource(R.drawable.hotel);
                button.setText("HOTEL");
                break;
            case 2:
                icon.setImageResource(R.drawable.flight);
                button.setText("FLIGHT");
                break;
            case 3:
                icon.setImageResource(R.drawable.visa);
                button.setText("VISA");
                break;
            case 4:
                icon.setImageResource(R.drawable.tour);
                button.setText("TOUR");
                break;
            case 5:
                icon.setImageResource(R.drawable.trans);
                button.setText("TRANSFER");
                break;
            case 6:
                icon.setImageResource(R.drawable.bus);
                button.setText("BUS");
                break;
            case 7:
                icon.setImageResource(R.drawable.sup);
                button.setText("SUPPORT");
                break;
        }





        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                int pos = getArguments().getInt("position");
                switch (pos){
                    case 0:
                        Intent intent = new Intent(getActivity(), Main3Activity.class);
                        startActivity(intent);
                        break;
                    case 1:
                        //
                        break;
                    case 2:
                        //
                        break;
                    case 3:
                        //
                        break;
                    case 4:
                        //
                        break;
                    case 5:
                        //
                        break;
                    case 6:
                        //
                        break;
                }

                /*
              if(getArguments().getInt("position")==1){
                  Intent intent = new Intent(getActivity(), Main3Activity.class);
                  //EditText editText = (EditText) findViewById(R.id.editText);
                  String message = "hi";//editText.getText().toString();
                  intent.putExtra(EXTRA_MESSAGE, message);
                  startActivity(intent);
              }else {
                  if (getArguments().getInt("position") == 2) {
                      Intent intent = new Intent(getActivity(), MainActivity.class);
                      //EditText editText = (EditText) findViewById(R.id.editText);
                      String message = "hi";//editText.getText().toString();
                      intent.putExtra(EXTRA_MESSAGE, message);
                      startActivity(intent);
                  } else {
                      Toast.makeText(getActivity(), "Button in Card " + getArguments().getInt("position")
                              + "Clicked!", Toast.LENGTH_SHORT).show();
                      Main2Activity.viewPager.setCurrentItem(getArguments().getInt("position") + 1, true);

                  }
              }
              */
            }
        });

        return view;
    }

    public CardView getCardView() {
        return cardView;
    }
}
