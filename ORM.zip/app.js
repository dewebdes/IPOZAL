var app = require('express')();
var http = require('http').createServer(app);
var io = require('socket.io')(http);
var url = require('url');
//var socks = 
function notifydevice(id){
	

	var sockets = io.sockets.sockets;
	for(var socketId in sockets)
	{
	  var socket = sockets[socketId]; //loop through and do whatever with each connected socket
	  //...
	  if(socket.device==id){
			socket.emit("runnotify","");
		}
	}

}
app.get('/', function(req, res){
  res.send('<h1>Hello world, My name is MaximORM.</h1>');
});
app.get('/samana-addlog', function(req, res){
  var logid = "0";
  console.log(req);
  var ip = req.connection.remoteAddress;
  var request = require('request');
  

  var urlprm = decodeURI(req.url).split("?");
  urlprm = urlprm[1].split("&");
  ip = urlprm[0].split("=")[1].split("%")[0];
  var dlog = urlprm[1].split("=")[1];
  console.log("samana log: "+ip+","+dlog);

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"getDeviceIdFromIp", dip: ip };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		console.log("device : "+body.trim());
		var ddevice = body.trim();
		var entry = dlog;//req.body;

notifydevice(ddevice);
	var s_tablename = "sam_logs";
    var s_flst = "dentry,dtime,deviceid";
    var dtime = Date.now();
    var s_vlst = "#sq#"+entry+"#sq#,#sq#"+dtime+"#sq#,#sq#"+ddevice+"#sq#";
    var s_where = "dtime=#sq#" + dtime + "#sq# AND deviceid=#sq#" + ddevice + "#sq#";

		//var propertiesObject = { api:"sql",cmd:"addLogForDevice", deviceid: device, dentry: entry };
		var propertiesObject = { api:"sql",cmd:"insertorupdate", tablename: s_tablename, flst: s_flst, vls: s_vlst, where: s_where, device: ddevice  };

		request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
			if(err) { console.log(err); return; }
			logid = body.trim();
			res.send(body);
		});
		
	});
  
});

io.on('connection', function(socket){
  socket.ip = "";
  socket.sys = "";
  socket.tkn = "";
  socket.project = "";
  socket.device = "0";

  //console.log('a user connected');
  var address = socket.handshake.address;
  socket.ip = address.address+":"+address.port;
  //console.log('New connection from ' + address.address + ':' + address.port);

  var socketId = socket.id;
  var clientIp = socket.request.connection.remoteAddress;
  socket.ip = clientIp;

  socket.on('disconnect', function(){
    //console.log('user disconnected');
  });

socket.on('select', function(msg){
    //console.log('divice detected: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    //var s_vlst = prm[2];
    var s_where = prm[2];
    console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"select",project: socket.project, tablename: s_tablename, flst: s_flst, where: s_where, device: socket.device  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		console.log("selectfill: "+body.trim())
		socket.emit('selectFill', body.trim());
		//socket.device = body;
		console.log("socket.device = "+socket.device);
	});

});
//mSocket.emit("loginme", us+","+ps);
socket.on('loginme', function(msg){
    //console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    var us = prm[0];
    var ps = prm[1];
    //var s_vlst = prm[2];
    //var s_where = prm[2];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"loginme", dus: us, dps: ps, device: socket.device, project:socket.project  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		var resv = parseInt(body);
		if(resv>0){
			socket.emit('loginres', "OK");
		}else{
			socket.emit('loginres', "ERR");
		}
		//socket.device = body;
		//console.log("socket.device = "+socket.device);
	});

});
//mSocket.emit("regme", name+","+ us+","+ps+","+autyp);
socket.on('regme', function(msg){
    //console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    var s_name = prm[0];
    var s_us = prm[1];
    var s_ps = prm[2];
    var s_autyp = prm[3];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"regme", name: s_name, us: s_us, ps: s_ps, autyp: s_autyp, device: socket.device, project:socket.project  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('regres', body);
		//socket.device = body;
		//console.log("socket.device = "+socket.device);
		var resv = parseInt(body);
		if(resv>0){
			socket.emit('regres', "OK");
		}else{
			socket.emit('regres', "ERR");
		}
	});

});
//mSocket.emit("getdivelist", "");
socket.on('getdivelist', function(msg){
   
	var request = require('request');
	console.log("get divive list...");
	var propertiesObject = { api:"sql",cmd:"getdivelist", project: socket.project, device: socket.device  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
	
		console.log("ret: "+body);
		socket.emit('setdevicelist', body);
	
	});

});

  socket.on('insertorupdate', function(msg){
    console.log('insertorupdate: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    var s_vlst = prm[2];
    var s_where = prm[3];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"insertorupdate",project:socket.project, tablename: s_tablename, flst: s_flst, vls: s_vlst, where: s_where, device: socket.device  };
console.log("***"+socket.device);
	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		//socket.device = body;
		console.log("insertorupdate = "+body);
	});

});

  socket.on('devicedetect', function(msg){
    //console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    socket.sys = prm[0];
    socket.tkn = prm[1];
    socket.project = prm[2];
    console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"DetectDevice", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log(err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		socket.device = body.trim();
		console.log("socket.device = "+socket.device);
	});

  });
});

http.listen(6907, function(){
  console.log('listening on *:6907');
});