var fs = require( 'fs' );
//const { exec } = require('child_process');
'use strict';

const express = require('express');
const fetch = require('node-fetch');
const redirectToHTTPS = require('express-http-to-https').redirectToHTTPS;

const app = express();
var https        = require('https');
var server = https.createServer({
    key: fs.readFileSync('./star_ipozal_com.key'),
    cert: fs.readFileSync('./STAR_ipozal_com.crt'),
    ca: fs.readFileSync('./STAR_ipozal_com.ca-bundle'),
    requestCert: false,
    rejectUnauthorized: false
},app);
server.listen(6907);

var io = require('socket.io').listen(server);
io.origins('*:*');
const iplocation = require("iplocation").default;

function replaceallstr(ts, tv, rv) {
while (ts.indexOf(tv) > -1) {
ts = ts.replace(tv, rv);
}
return ts;
}

function gettimetick() {
var date = new Date();
var ticks = date.getTime();
return ticks;
}

function isnullval(tval) {
retval = false;
try {
if ((tval == "") || (tval == undefined) || (tval == null) || (tval==NaN) || (jQuery.trim(tval) == "")) { retval = true; }
} catch (ex) {
retval = false;
}
return retval;
}


io.sockets.on('connection',function (socket) {
    console.log('connect..');
	handlesocket(socket);
});
app.use(express.static('public'));
app.get("/api", function(request, response){
   response.send('hi');
})

app.get("/newpage/", function(request, response){
console.log('newpage');
//console.log('BIG insertorupdate: ' + msg);
    var tablename = request.query.tablename;
var fls = request.query.fls;
var dplc=request.query.dplc;
var dtm=request.query.dtm;
var dur=request.query.dur;
var wuuid=request.query.wuuid;
var tit=request.query.tit;
var dpic=request.query.dpic;
var duser=request.query.duser;
var dpost=request.query.dpost;
var dsubj=request.query.dsubj;
var wgeo=request.query.wgeo;
var vls=request.query.vls;
var where=request.query.where;
   
	var request2 = require('request');
	var propertiesObject = { api:"sql",cmd:"insertorupdate",project:'ipozal', tablename: tablename, flst: fls, vls: vls, where: where, device: "0"  };

	request2({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response2, body) {
		if(err) { console.log("**ERROR: "+err); return; }
//console.log('echo "'+dur+'" | mail -s "IPOZAL New Page" '+duser+' < /var/www/html/mail.ipozal.com/actor-man/index.html');


exec('echo "'+dur+'" | mail -s "IPOZAL New Page" '+duser+' < /var/www/html/mail.ipozal.com/actor-man/index.html', (err, stdout, stderr) => {
  if (err) {
    // node couldn't execute the command
    return;
  }

  // the *entire* stdout and stderr (buffered)
  console.log(`stdout: ${stdout}`);
  console.log(`stderr: ${stderr}`);
});


		response.send("<h1>Check your MailBox: <u>"+duser+"</u></h1>");
		console.log("insertorupdate = "+body);
	});

    
})

var app2 = require('express')();
var http = require('http');
//http.createServer(function (req, res) {
    //res.writeHead(301, { "Location": "https://" + req.headers['host'] + req.url });
    //res.end();
	//res.send('hi2');
//},app2).listen(6908);
var server2 = http.createServer(app2);
server2.listen(6908);

var clientIp;
var io2 = require('socket.io').listen(server2);
io2.origins('*:*');
io2.sockets.on('connection',function (socket) {
    console.log('connect 2..');
 clientIp = socket.request.connection.remoteAddress.split(":")[3];
	handlesocket(socket);
});

var uuid = require('node-uuid');
var port = process.argv[2] || 6908;
var path = require('path');
var exec = require('child_process').exec;
var url = require('url');

var regalpha = "،. 123456789,0-/q_wertyuiopasdfghjklzxc،v#bn@mآ?&:=ضصثقفغعهخحجچشسیبلاتنمکگپظطزرذدئوژ";
function havsqlinj(dt){
  for (var k in dt){
      //if (typeof target[k] !== 'function') {
  //         alert("Key i " + k + ", value is" + target[k]);
  var st=dt[k];

      //}
  var ret=false;
  var urstring=st;
  if(isNaN(st)==true){
  urstring=(st.toLowerCase());
  }
  var dlength = (urstring.length);
  //$thisWordCodeVerdeeld = array();
  for (var ix=0; ix<dlength; ix++) {
  if (regalpha.indexOf(urstring[ix]) > -1) {
  a=1;
  }else{
  if(((urstring[ix]).charCodeAt(0) != 46) && ((urstring[ix]).charCodeAt(0) != 37) && ((urstring[ix]).charCodeAt(0) != 32) && ((urstring[ix]).charCodeAt(0) != 10) && ((urstring[ix]).charCodeAt(0) != 8204)){
  //echo("<script>alert('" . ord($urstring[$i]) . "');</script>");
  ret=true;
  //console.log("st bad::" + st + "badchar = (" + urstring[ix] + ") ascii=" + (urstring[ix]).charCodeAt(0));
  return true;
  }
  //return;

  }
  }
  }

}

function cash(cmd,prm,res){
this.cmd=cmd;
this.prm=prm;
this.res=res;
}

var cashar=new Array();

function getcash(c,p){
  for(var i=0;i<=cashar.length-1;i++){
    if(cashar[i].cmd==c){
      if(cashar[i].prm==p){
        return cashar[i].res;
      }
    }
  }
return "ns";
}

function S4() {
  return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}

function id() {
  return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
}


function handlesocket(socket){

console.log(clientIp);

	socket.id = id();
socket.emit("setttkkid",socket.id);
	socket.ip = "";
	socket.sys = "";
  socket.tkn = "";
  socket.user = "";
  socket.project = "";
  socket.device = "0";
var address = socket.handshake.address;
  //socket.ip = address.address+":"+address.port;
  //console.log('New connection from ' + address.address + ':' + address.port);
var socketId = socket.id;
var ip = clientIp;//socket.handshake.headers ['x-forwarded-for'];
iplocation(ip, [], (error, res) => {
socket.ip=ip;//res;
  console.log("res ip loc = "+JSON.stringify(res));
  // {"country":"IR","countryCode":"IR","region":"Tehran","regionCode":"","city":"Jamshidiyeh","postal":"","ip":"85.133.201.5","latitude":35.7128,"longitude":51.3806,"timezone":""}
  socket.emit("iploc",res);

})
socket.ip = ip;
socket.on('disconnect', function(){
    ////console.log('user disconnected');
  });
socket.on('saveblob', function(msg){
	//console.log("save blobs :: "+msg.length);
	////console.log("save blobs :: "+msg);
	saveBlob(socket.id,msg,'web','chrome');
});

socket.on('checkpassprotect', function(msg){
console.log('check...');

var ret = new Array();
if(true){//msg.pass=="ipozal"){


	fs.readdir('/root/APPS/TelNet/uploads/patm/', function(err, filenames) {
	if (err) {
		onError(err);
		return;
	}
		filenames.forEach(function(filename) {

if(filename.indexOf('-fade')==-1){
//socket.emit('checkpassprotect',new nwf(filename,base64_encode('/root/APPS/TelNet/uploads/patm/' + filename)));
}
			
		});
	});
socket.emit('hideprotect','ok');
}else{
socket.emit('checkpassprotect','er');
}

});


socket.on('getfile', function(msg){

  
  fs.readFile('/var/www/html/MaximORM/uploads/'+msg.fn, (err, data) => {
  if (err) throw err;
  socket.emit("getfile",{fn:msg.fn,bin:data});
  });

});

socket.on('getstreams', function(msg){
  if(msg.length==0){
  	var outx = "";
  	for(var i=0;i<=StreamsArr.length-1;i++){
  		outx += StreamsArr[i].skid+"#np#";
  	}
  	socket.emit("liststreams",outx);
  //function streamobj(skid,barr,soft,device){  
  }
  else{
    var tar = msg.split('---');
    var tit = tar[0];
    var indx = parseInt(tar[1]);
    var counter = 0;
    var outar = new Array();
    //console.log("StreamsArr.length = "+StreamsArr.length);
    for(var i=0;i<=StreamsArr.length-1;i++){
      //console.log(StreamsArr[i].skid.trim()+" == "+tit.trim());
      if(StreamsArr[i].skid.trim() == tit.trim()){
        //console.log("...found "+counter);
        for(var j=0;j<=StreamsArr[i].barr.length;j++){
          if(indx < counter){
            outar[outar.length] = StreamsArr[i].barr[j];
          }
          counter++;
        }
      }
    }
    //console.log("= "+outar.length);
    socket.emit("showstream",outar);
  }
});

socket.on('save1', function(msg){
  //console.log("---- got");
  //socket.emit("run1",msg);
  socket.emit("justgot","");
});
socket.on('select', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    //var s_vlst = prm[2];
    var s_where = prm[2];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"select",project: socket.project, tablename: s_tablename, flst: s_flst, where: s_where, device: socket.device  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//console.log("selectfill: "+body.trim())
		socket.emit('selectFill', body.trim());
		//socket.device = body;
		//console.log("socket.device = "+socket.device);
	});

});
//mSocket.emit("loginme", us+","+ps);
socket.on('loginme', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    var us = prm[0];
    var ps = prm[1];
    //var s_vlst = prm[2];
    //var s_where = prm[2];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"loginme", dus: us, dps: ps, device: socket.device, project:socket.project  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		var resv = parseInt(body);
		if(resv>0){
			socket.emit('loginres', "OK");
		}else{
			socket.emit('loginres', "ERR");
		}
		//socket.device = body;
		////console.log("socket.device = "+socket.device);
	});

});
//mSocket.emit("regme", name+","+ us+","+ps+","+autyp);
socket.on('regme', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    var s_name = prm[0];
    var s_us = prm[1];
    var s_ps = prm[2];
    var s_autyp = prm[3];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"regme", name: s_name, us: s_us, ps: s_ps, autyp: s_autyp, device: socket.device, project:socket.project  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('regres', body);
		//socket.device = body;
		////console.log("socket.device = "+socket.device);
		var resv = parseInt(body);
		if(resv>0){
			socket.emit('regres', "OK");
		}else{
			socket.emit('regres', "ERR");
		}
	});

});
//mSocket.emit("getdivelist", "");
socket.on('getdivelist', function(msg){
   
	var request = require('request');
	//console.log("get divive list...");
	var propertiesObject = { api:"sql",cmd:"getdivelist", project: socket.project, device: socket.device  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
	
		//console.log("ret: "+body);
		socket.emit('setdevicelist', body);
	
	});

});
socket.on('savemapcap', function(msg){
  var nc = new captureobj(msg.tit,msg.bs.split(',')[1]);
  var fnd = false;
  for(var i=0;i<=capsAr.length-1;i++){
    if(capsAr[i].tit == msg.tit){
      fnd = true;
      capsAr[i].bs = msg.bs.split(',')[1];
      break;
    }
  }
  if(fnd == false){
    capsAr[capsAr.length] = nc;
  }
});
socket.on('getmapcap', function(msg){
  //var nc = new captureobj(msg.tit,msg.bs);
  var fnd = false;
  for(var i=0;i<=capsAr.length-1;i++){
    if(capsAr[i].tit == msg.tit){
      fnd = true;
      socket.emit("setmapcap",capsAr[i].bs);
      break;
    }
  }
  if(fnd == false){
    //capsAr[capsAr.length] = nc;
  }
});


socket.on('BIGinsertorupdate', function(msg){
    console.log('BIG insertorupdate: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    var s_vlst = prm[2];
    var s_where = prm[3];
    console.log('insertorupdate: ' + msg);
   
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"insertorupdate",project:socket.project, tablename: s_tablename, flst: s_flst, vls: s_vlst, where: s_where, device: socket.device  };
//console.log("***"+socket.device);
	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
socket.emit('inupok', {jsn : body});
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		//socket.device = body;
		console.log("insertorupdate = "+body);
	});

});


  socket.on('insertorupdate', function(msg){
    console.log('insertorupdate: ' + msg);
    var prm = msg.split("|");
    var s_tablename = prm[0];
    var s_flst = prm[1];
    var s_vlst = prm[2];
    var s_where = prm[3];
    ////console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"insertorupdate",project:socket.project, tablename: s_tablename, flst: s_flst, vls: s_vlst, where: s_where, device: socket.device  };
//console.log("***"+socket.device);
	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		socket.emit('inupok', {jsn : body});
		//socket.device = body;
		console.log("insertorupdate = "+body);
	});

});

  socket.on('devicedetect', function(msg){
    ////console.log('divice detected: ' + msg);
    var prm = msg.split(",");
    socket.sys = prm[0];
    socket.tkn = prm[1];
    socket.project = prm[2];
    //console.log("project: "+socket.project+" , ip: "+socket.ip+" , sys: "+socket.sys+" , tkn: "+socket.tkn);

	var request = require('request');

	//var propertiesObject = { api:"sql",cmd:"runquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	//var propertiesObject = { api:"sql",cmd:"selectquery", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn, query: "DetectDevice"  };
	var propertiesObject = { api:"sql",cmd:"DetectDevice", entry: "", skid: socketId, project: socket.project, ip: socket.ip, sys: socket.sys, tkn: socket.tkn  };

	request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
		if(err) { console.log("**ERROR: "+err); return; }
		//var ncash = new cash("MGgetCats",dprm,body);
		//cashar[cashar.length] = ncash;
		//socket.emit('MGwriteCats', {jsn : body});
		socket.device = body.trim();
		//console.log("socket.device = "+socket.device);
    socket.emit("setdeviceid",socket.device);

      var propertiesObject = { api:"sql",cmd:"DetectUser", dv: socket.device };

      request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
        if(err) { console.log("**ERROR: "+err); return; }
        socket.user = body.trim();
        //console.log("socket.user = "+socket.user);
        socket.emit("setuserid",socket.user);
      });



	});

  });

  socket.on('DetectUser', function (data) {
      var request = require('request');
      var propertiesObject = { api:"sql",cmd:"DetectUser", dv: data };

      request({url:'http://maxim.shop/exc.php', qs:propertiesObject}, function(err, response, body) {
        if(err) { console.log("**ERROR: "+err); return; }
        socket.user = body.trim();
        //console.log("socket.user = "+socket.user);
        socket.emit("setuserid",socket.user);
      });

  });

	socket.on('streammessage', function (data) {
	        var fileName = uuid.v4();
	        
	        socket.emit('ffmpeg-output', 0);

	        writeToDisk(data.audio.dataURL, fileName + '.wav');

	        // if it is chrome
	        if (data.video) {
	            writeToDisk(data.video.dataURL, fileName + '.webm');
	            merge(socket, fileName);
	        }

	        // if it is firefox or if user is recording only audio
	        else socket.emit('merged', fileName + '.wav');
	});

	socket.on('message', function(msg) {
		//const buf2 = Buffer.from(msg);
		////console.log("message is : "+roughSizeOfObject(msg)+" - "+ objToString(msg));
      //var json = JSON.parse(msg);
      //rtc.fire(json.eventName, json.data, socket);
    });

    socket.on('close', function() {
      iolog('close');

    });
    


}

function writeToDisk(dataURL, fileName) {
    var fileExtension = fileName.split('.').pop(),
        fileRootNameWithBase = './uploads/' + fileName,
        filePath = fileRootNameWithBase,
        fileID = 2,
        fileBuffer;

    // @todo return the new filename to client
    while (fs.existsSync(filePath)) {
        filePath = fileRootNameWithBase + '(' + fileID + ').' + fileExtension;
        fileID += 1;
    }

    dataURL = dataURL.split(',').pop();
    fileBuffer = new Buffer(dataURL, 'base64');
    fs.writeFileSync(filePath, fileBuffer);

    //console.log('filePath', filePath);
}
function roughSizeOfObject( object ) {

	var objectList = [];
	var stack = [ object ];
	var bytes = 0;

	while ( stack.length ) {
	var value = stack.pop();

	if ( typeof value === 'boolean' ) {
	bytes += 4;
	}
	else if ( typeof value === 'string' ) {
	bytes += value.length * 2;
	}
	else if ( typeof value === 'number' ) {
	bytes += 8;
	}
	else if
	(
	typeof value === 'object'
	&& objectList.indexOf( value ) === -1
	)
	{
	objectList.push( value );

	for( var i in value ) {
	stack.push( value[ i ] );
	}
	}
	}
	return bytes;
}
function merge(socket, fileName) {
    var FFmpeg = require('fluent-ffmpeg');

    var audioFile = path.join(__dirname, 'uploads', fileName + '.wav'),
        videoFile = path.join(__dirname, 'uploads', fileName + '.webm'),
        mergedFile = path.join(__dirname, 'uploads', fileName + '-merged.webm');

    new FFmpeg({
            source: videoFile
        })
        .addInput(audioFile)
        .on('error', function (err) {
            socket.emit('ffmpeg-error', 'ffmpeg : An error occurred: ' + err.message);
        })
        .on('progress', function (progress) {
            socket.emit('ffmpeg-output', Math.round(progress.percent));
        })
        .on('end', function () {
            socket.emit('merged', fileName + '-merged.webm');
            //console.log('Merging finished !');

            // removing audio/video files
            fs.unlink(audioFile);
            fs.unlink(videoFile);
        })
        .saveToFile(mergedFile);
}


//-----mail-parser
var mailsr=new Array();
var mailsr2=new Array();

const simpleParser = require('mailparser').simpleParser;

var intmchk;
function funcxrpt(){
clearInterval(intmchk);
console.log('hi from xx');
fs.readdir('/home/yto/Maildir/new', function(err, filenames) {
	if (err) {
		onError(err);
		return;
	}
	mailsr=filenames;
	if(mailsr.length > mailsr2.length){
		var indx=mailsr2.length;
		filenames.forEach(function(filename) {
			if(indx<mailsr.length ){
				fs.readFile('/home/yto/Maildir/new/'+filename, (err, data) => {
				  if (err){ //throw err;
					}else{
						simpleParser(data).then(function(mail_object) {
						  console.log("From:", mail_object.from.value);
						  console.log("Subject:", mail_object.subject);
						  console.log("Text body:", mail_object.text);


						var parsed = mail_object;


						console.log("\n\n\n NEW MAIL ARRIVED - "+indx+" \n "+parsed+" \n\n\n");
						console.log("headers – a Map object with lowercase header keys: "+parsed.headers+"\n");
						console.log("subject is the subject line (also available from the header mail.headers.get(‘subject’)): "+parsed.subject+"\n");
						console.log("from is an address object for the From: header: "+parsed.from+"\n");
						console.log("to is an address object for the To: header: "+parsed.header+"\n");
						console.log("cc is an address object for the Cc: header: "+parsed.cc+"\n");
						console.log("bcc is an address object for the Bcc: header (usually not present): "+parsed.bcc+"\n");
						console.log("date is a Date object for the Date: header: "+parsed.date+"\n");
						console.log("messageId is the Message-ID value string: "+parsed.messageId+"\n");
						console.log("inReplyTo is the In-Reply-To value string: "+parsed.inReplyTo+"\n");
						try{
						console.log("reply-to is an address object for the Cc: header: "+parsed.reply-to+"\n");
						}catch(ex){}
						console.log("references is an array of referenced Message-ID values: "+parsed.references+"\n");
						console.log("html is the HTML body of the message. If the message included embedded images as cid: urls then these are all replaced with base64 formatted data: URIs: "+parsed.headers+"\n");
						console.log("text is the plaintext body of the message: "+parsed.headers+"\n");
						console.log("textAsHtml is the plaintext body of the message formatted as HTML: "+parsed.headers+"\n");
						console.log("attachments is an array of attachments: "+parsed.headers+"\n");
				}).catch(function(err) {
				  console.log('An error occurred:', err.message);
				});

					}
			  	});	
				indx++;
			}
		});
	}
});
mailsr2=mailsr;
intmchk = setInterval(funcxrpt,1000);
}
funcxrpt();

//intmchk = setInterval(funcxrpt,1000);

