phantom.create(["--proxy-type=socks5 --proxy=127.0.0.1:9050"])
      .then((instance) => {
          phInstance = instance;
          return instance.createPage();
      })
      .then((page) => {
          sitepage = page;
          return page.open('http://ipozal.com/ip.php');
      })
      .then((status) => {
          console.log(status);
          return sitepage.property('title');
      })
      .then((content) => {
          console.log(content);
          sitepage.close();
          phInstance.exit();
      })
      .catch((error) => {
          console.log(error);
          phInstance.exit();
      });
