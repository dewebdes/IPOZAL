var webPage = require('webpage');
var page = webPage.create();

page.open('http://ipozal.com/ip.php', function (status) {
  console.log('Stripped down page text:\n' + page.plainText);
  phantom.exit();
});

